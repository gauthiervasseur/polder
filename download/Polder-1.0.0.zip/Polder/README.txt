POLDER 1.0.0 - business intelligence for CSV files, made for DLL
===============================================================

START
  Double-click index.html. It opens in your web browser (Chrome, Edge,
  Firefox or Safari). Nothing to install, no internet needed, and your data
  never leaves your computer.

USE
  1. Load CSV (or drop a .csv file onto the window). Try samples/lowlands-asset-finance.csv.
  2. Drag fields from the left onto Columns, Rows, Values and Color.
  3. Pick a chart type, or leave Auto.
  4. Drop fields on Filters to filter. Use the swap button to pivot rows and columns.
  5. Click a pill to change Sum/Average/... or Year/Month/...

THEMES
  The default theme uses DLL's colours. Theme CSS loads a .css file with your
  own colors and fonts. Examples are in themes/. Supported variables are
  listed in the Theme tab and in themes/dll.css.

SAVE / OPEN
  Save writes a .polder.json file with your sheets, filters and theme (not the
  data). Open it, then load the matching CSV.

CREDITS
  Charts: plotly.js (MIT license) - vendor/
  Font: Figtree (SIL Open Font License) - fonts/. DLL's Effra is used when installed.
  Demo data: fictional (Lowlands Asset Finance) - not real DLL data.
